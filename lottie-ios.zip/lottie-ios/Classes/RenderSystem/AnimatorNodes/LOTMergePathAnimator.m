//
//  LOTMergePathAnimator.m
//  lottie-ios-iOS
//
//  Created by huya on 2018/6/20.
//

#import "LOTMergePathAnimator.h"
#import "LOTPathAnimator.h"
#import "LOTRoundedRectAnimator.h"
#import "LOTCircleAnimator.h"
#import "LOTPolystarAnimator.h"
#import "LOTPolygonAnimator.h"
#import "CGPath+Boolean.h"

@interface LOTMergePathAnimator() {
    NSArray* _mergeContents;
    LOTShapeMergePath* _shapeMergePath;
    BOOL _rootNodeHasUpdate;
    NSArray* _mergeAnimatedNodes;
}

@end

@implementation LOTMergePathAnimator

- (instancetype _Nonnull)initWithInputNode:(LOTAnimatorNode *_Nullable)inputNode
                              pathContents:(NSArray* _Nullable)pathContents
                                 shapePath:(LOTShapeMergePath *_Nonnull)shapePath
{
    if (self = [super initWithInputNode:inputNode keyName:shapePath.keyname]) {
        _mergeContents  = pathContents;
        _shapeMergePath = shapePath;
        [self buildContents:pathContents];
        
    }
    return self;
}

- (void)buildContents:(NSArray *)contents {
    
    NSMutableArray* nodes = [NSMutableArray arrayWithCapacity:contents.count];
    
    for (id item in contents) {
        if ([item isKindOfClass:[LOTShapePath class]]) {
            LOTPathAnimator *pathAnimator = [[LOTPathAnimator alloc] initWithInputNode:nil
                                                                             shapePath:(LOTShapePath *)item];
            [nodes addObject:pathAnimator];
        } else if ([item isKindOfClass:[LOTShapeRectangle class]]) {
            LOTRoundedRectAnimator *rectAnimator = [[LOTRoundedRectAnimator alloc] initWithInputNode:nil
                                                                                      shapeRectangle:(LOTShapeRectangle *)item];
            [nodes addObject:rectAnimator];
        } else if ([item isKindOfClass:[LOTShapeCircle class]]) {
            LOTCircleAnimator *circleAnimator = [[LOTCircleAnimator alloc] initWithInputNode:nil
                                                                                 shapeCircle:(LOTShapeCircle *)item];
            [nodes addObject:circleAnimator];
        } else if ([item isKindOfClass:[LOTShapeStar class]]) {
            LOTShapeStar *star = (LOTShapeStar *)item;
            if (star.type == LOTPolystarShapeStar) {
                LOTPolystarAnimator *starAnimator = [[LOTPolystarAnimator alloc] initWithInputNode:nil shapeStar:star];
                [nodes addObject:starAnimator];
            }
            if (star.type == LOTPolystarShapePolygon) {
                LOTPolygonAnimator *polygonAnimator = [[LOTPolygonAnimator alloc] initWithInputNode:nil shapePolygon:star];
                [nodes addObject:polygonAnimator];
            }
        }
    }
    
    _mergeAnimatedNodes = nodes;
}

- (BOOL)needsUpdateForFrame:(NSNumber *)frame {
    return (_rootNodeHasUpdate);
    
}

- (BOOL)updateWithFrame:(NSNumber *)frame withModifierBlock:(void (^ _Nullable)(LOTAnimatorNode * _Nonnull))modifier forceLocalUpdate:(BOOL)forceUpdate {
    indentation_level = indentation_level + 1;
    
    BOOL hasOneUpdated = NO;
    for (NSInteger i = 0; i < _mergeAnimatedNodes.count; i++) {
        LOTAnimatorNode* node = [_mergeAnimatedNodes objectAtIndex:i];
        BOOL hasAnimatedNodeUpdate = [node updateWithFrame:frame withModifierBlock:modifier forceLocalUpdate:forceUpdate];
        if (hasAnimatedNodeUpdate) {
            hasOneUpdated = YES;
        }
    }
    
    indentation_level = indentation_level - 1;
    _rootNodeHasUpdate = hasOneUpdated;
    BOOL update = [super updateWithFrame:frame withModifierBlock:modifier forceLocalUpdate:forceUpdate];
    return update;
}

- (void)opMergeContents
{
    LOTBezierPath* remindePath = [[LOTBezierPath alloc] init];
    
    for (NSInteger i = 1; i < _mergeAnimatedNodes.count; i++) {
        LOTAnimatorNode* node = [_mergeAnimatedNodes objectAtIndex:i];
        [remindePath LOT_appendPath:node.outputPath];
    }
    
    LOTAnimatorNode* firstNode = _mergeAnimatedNodes.count > 0 ? [_mergeAnimatedNodes firstObject] : nil;
    LOTBezierPath* firstPath = firstNode.outputPath;
    CGPathRef mergeCGPath = NULL;
    BOOL shouldReleaseMergePath = NO;
    
    if (firstNode && _mergeAnimatedNodes.count) {
        
        switch (_shapeMergePath.mode) {
            case LOTShapeMergeModeMerge: {
                [firstPath LOT_appendPath:remindePath];
                mergeCGPath = firstPath.CGPath;
                break;
            }
            case LOTShapeMergeModeAdd: {
                mergeCGPath = CGPathUnion(firstPath.CGPath, remindePath.CGPath);
                shouldReleaseMergePath = YES;
                break;
            }
            case LOTShapeMergeModeSubtract: {
                mergeCGPath = CGPathDifference(firstPath.CGPath, remindePath.CGPath);
                shouldReleaseMergePath = YES;
                break;
            }
            case LOTShapeMergeModeIntersect: {
                mergeCGPath = CGPathIntersect(firstPath.CGPath, remindePath.CGPath);
                shouldReleaseMergePath = YES;
                break;
            }
            case LOTShapeMergeModeExcludeIntersections: {
                mergeCGPath = CGPathXOR(firstPath.CGPath, remindePath.CGPath);
                shouldReleaseMergePath = YES;
                break;
            }
            default:
                break;
        }
        
    } else if(firstNode) {
        mergeCGPath = firstPath.CGPath;
    } else {
        mergeCGPath = self.inputNode ? self.inputNode.outputPath.CGPath : NULL;
    }
    
    if (mergeCGPath != NULL) {
        self.localPath = [LOTBezierPath pathWithCGPath:mergeCGPath];
    } else {
        self.localPath = [[LOTBezierPath alloc] init];
    }
    
    if (mergeCGPath != NULL && shouldReleaseMergePath) {
        CGPathRelease(mergeCGPath);
    }
}

- (void)performLocalUpdate
{
    [self opMergeContents];
}

@end
