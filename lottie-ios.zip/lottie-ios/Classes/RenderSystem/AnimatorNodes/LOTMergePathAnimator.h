//
//  LOTMergePathAnimator.h
//  lottie-ios-iOS
//
//  Created by huya on 2018/6/20.
//

#import "LOTAnimatorNode.h"
#import "LOTShapeMergePath.h"

@interface LOTMergePathAnimator : LOTAnimatorNode

- (instancetype _Nonnull)initWithInputNode:(LOTAnimatorNode *_Nullable)inputNode
                              pathContents:(NSArray* _Nullable)pathContents
                                 shapePath:(LOTShapeMergePath *_Nonnull)shapePath;

@end
