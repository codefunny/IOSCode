//
//  FBDebug.h
//  VectorBoolean
//
//  Created by Andrew Finnell on 6/17/11.
//  Copyright 2011 Fortunate Bear, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>


NSString *FBArrayDescription(NSArray *array);
