//
//  Prefix header
//
//  The contents of this file are implicitly included at the beginning of every source file.
//

#ifdef __OBJC__
    #import <UIKit/UIKit.h>
	#import <Foundation/Foundation.h>
	#import <CoreGraphics/CoreGraphics.h>

    #define NSMinX CGRectGetMinX
    #define NSMaxX CGRectGetMaxX
    #define NSMinY CGRectGetMinY
    #define NSMaxY CGRectGetMaxY
    #define NSWidth CGRectGetWidth
    #define NSHeight CGRectGetHeight
    #define NSPoint CGPoint
#endif
