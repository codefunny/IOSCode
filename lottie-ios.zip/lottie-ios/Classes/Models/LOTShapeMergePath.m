//
//  LOTShapeMergePath.m
//  lottie-ios-iOS
//
//  Created by huya on 2018/6/20.
//

#import "LOTShapeMergePath.h"

@implementation LOTShapeMergePath

- (instancetype)initWithJSON:(NSDictionary *)jsonDictionary {
    self = [super init];
    if (self) {
        [self _mapFromJSON:jsonDictionary];
    }
    return self;
}

- (void)_mapFromJSON:(NSDictionary *)jsonDictionary {
    
    if (jsonDictionary[@"nm"] ) {
        _keyname = [jsonDictionary[@"nm"] copy];
    }
    
    if (jsonDictionary[@"mm"]) {
        _mode = [jsonDictionary[@"mm"] intValue];
    }
}

@end
