//
//  LOTShapeMergePath.h
//  lottie-ios-iOS
//
//  Created by huya on 2018/6/20.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    LOTShapeMergeModeMerge = 1,
    LOTShapeMergeModeAdd,
    LOTShapeMergeModeSubtract,
    LOTShapeMergeModeIntersect,
    LOTShapeMergeModeExcludeIntersections
} LOTShapeMergeMode;

@interface LOTShapeMergePath : NSObject

- (instancetype)initWithJSON:(NSDictionary *)jsonDictionary;

@property (nonatomic, readonly) NSString *keyname;
@property (nonatomic, readonly) LOTShapeMergeMode mode;

@end
